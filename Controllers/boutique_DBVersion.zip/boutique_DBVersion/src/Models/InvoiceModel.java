package Models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class InvoiceModel {

    private int invoiceItemId;
    private int garmentId;
    private int quantity;
    private double price;

    public InvoiceModel(int invoiceItemId, int garmentId, int quantity, double price) {
        setInvoiceItemId(invoiceItemId);
        setGarmentId(garmentId);
        setQuantity(quantity);
        setPrice(price);
    }
    
    public int getInvoiceItemId() {
        return invoiceItemId;
    }
    
    public void setInvoiceItemId(int invoiceItemId) {
        this.invoiceItemId = invoiceItemId;
    }
    
    public int getGarmentId() {
        return garmentId;
    }
    
    public void setGarmentId(int garmentId) {
        this.garmentId = garmentId;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }

//	public String toString() {
//		String a=(garmentsList==null)?"the inventory is empty": garmentsList.toString();
//		return "InvoiceModel{" +
//				"ShopName='" + ShopName + '\'' +
//				"garmentsList"+a+
//				", totalPrice=" + totalPrice +
//				", totalPricePerType=" + totalPricePerType +
//				", cashierID=" + cashierID +
//				", empName='" + empName + '\'' +
//				", invoiceID=" + invoiceID +
//
//				", date=" + date +
//				'}';
//	}
}
