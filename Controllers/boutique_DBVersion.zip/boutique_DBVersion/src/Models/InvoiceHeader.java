package Models;

import java.util.Date;

public class InvoiceHeader {
    
    private int invoiceItemId;
    private int cashierId;
    private final String ShopName = "Boutique";

    public InvoiceHeader(int invoiceItemId, int cashierId) {
        setInvoiceItemId(invoiceItemId);
        setCashierId(cashierId);
        
    }

    public int getInvoiceItemId() {
        return invoiceItemId;
    }
    
    public void setInvoiceItemId(int invoiceItemId) {
        this.invoiceItemId = invoiceItemId;
    }
    
    public int getCashierId() {
        return cashierId;
    }
    
    public void setCashierId(int cashierId) {
        this.cashierId = cashierId;
    }
}