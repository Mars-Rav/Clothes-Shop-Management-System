package Helpers;

import static Helpers.Config.*;
import Models.GarmentModel;
import Models.InvoiceHeader;
import Models.InvoiceModel;
import Models.User;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class dataBaseOperation {

    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
    Connection conn;

    public dataBaseOperation() throws SQLException {
        conn = DriverManager.getConnection(DB_URL, USER, PASS);
    }

    public ResultSet getAllGarments() throws SQLException {
        String query = "SELECT * FROM garments";
        Statement stmt = conn.createStatement();
        ResultSet result = stmt.executeQuery(query);
        return result;

    }

    public ResultSet getAllusers() throws SQLException {
        String query = "SELECT * FROM users";
        Statement stmt = conn.createStatement();
        ResultSet result = stmt.executeQuery(query);
        return result;

    }

    public ResultSet getAllInvoiceList() throws SQLException {
        String query = "SELECT * FROM invoice_list";
        Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ResultSet result = stmt.executeQuery(query);
        return result;

    }

    public ResultSet getAllInvoiceHeader() throws SQLException {
        String query = "SELECT * FROM invoice_header";
        Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ResultSet result = stmt.executeQuery(query);
        return result;

    }

    public ResultSet getOneInvoiceHeader(int id) throws SQLException {
        String query = "SELECT * FROM invoice_header WHERE invoice_id=" + id;
        Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ResultSet result = stmt.executeQuery(query);
        return result;

    }

    public GarmentModel insert(int id, String name, String barcode, String brand, String size, String color, String model, double price, int quantity, String category, double discount, String description) throws SQLException, IOException {
        String query
                = "INSERT INTO garments"
                + "(garment_id,name, barcode, brand, size, color, model, price, quantity, category,discount, description)"
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, id);
        ps.setString(2, name);
        ps.setString(3, barcode);
        ps.setString(4, brand);
        ps.setString(5, size);
        ps.setString(6, color);
        ps.setString(7, model);
        ps.setDouble(8, price);
        ps.setInt(9, quantity);
        ps.setString(10, category);
        ps.setDouble(11, discount);
        ps.setString(12, description);

        ps.executeUpdate();

        GarmentModel g = new GarmentModel(id, name, barcode, brand, size, color, model, price, quantity, category, discount, description);
        ps.close();
        return g;

    }

    public void updateDataGarment(int id, String name, String barcode, String brand, String size, String color, String model, double price, int quantity, String category, int discount, String description) throws SQLException {

        String query
                = "UPDATE garments SET name=?, barcode=?, brand=?, size=?, color=?, model=?, price=?, quantity=?, category=?,discount=?, description=? WHERE id=?";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setString(1, name);
        ps.setString(2, barcode);
        ps.setString(3, brand);
        ps.setString(4, size);
        ps.setString(5, color);
        ps.setString(6, model);
        ps.setDouble(7, price);
        ps.setInt(8, quantity);
        ps.setString(9, category);
        ps.setInt(10, discount);
        ps.setString(11, description);
        ps.setInt(12, id);

        ps.executeUpdate();

    }

    public void delete(int id) throws SQLException {
        String query = "DELETE FROM garments WHERE garment_id = ? ";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, id);
        ps.executeUpdate();

    }

    public void deleteInvoice(int id) throws SQLException {
        String query = "DELETE FROM invoice WHERE invoice_id = ? ";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, id);
        ps.executeUpdate();

    }

    public User insert(int id, String name, String gender, String dob, String phoneNumber, String email, double salary, String address, String password, String role) throws SQLException, IOException {
        String query
                = "INSERT INTO users"
                + "(user_id,name, gender, dob, phoneNumber, email, salary, address, password,role)"
                + "VALUES (?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, id);
        ps.setString(2, name);
        ps.setString(3, gender);
        ps.setString(4, dob);
        ps.setString(5, phoneNumber);
        ps.setString(6, email);
        ps.setDouble(7, salary);
        ps.setString(8, address);
        ps.setString(9, password);
        ps.setString(10, role);
        ps.executeUpdate();
        User u = new User(id, name, gender, dob, phoneNumber, email, salary, address, password, role);
        ps.close();
        return u;

    }

    public void delete(int id, String name) throws SQLException {
        String query = "DELETE FROM users WHERE user_id = ? AND name=? ";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, id);
        ps.setString(2, name);
        ps.executeUpdate();
    }

    public InvoiceModel insert(int invoiceItemId, int garmentId, int quantity, double price) throws SQLException, IOException {
        String query
                = "INSERT INTO invoice_items"
                + "(invoice_items_id, garment_id, quantity, price)"
                + "VALUES (?,?,?,?)";
        PreparedStatement ps = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ps.setInt(1, invoiceItemId);
        ps.setInt(2, garmentId);
        ps.setInt(3, quantity);
        ps.setDouble(4, price);

        ps.executeUpdate();

        InvoiceModel invoice = new InvoiceModel(invoiceItemId, garmentId, quantity, price);
        ps.close();
        return invoice;

    }

    public InvoiceHeader insert(int invoiceItemId, int cashierId) throws SQLException, IOException {
        String query
                = "INSERT INTO invoice"
                + "(invoice_items_id, cashier_id)"
                + "VALUES (?,?)";
        PreparedStatement ps = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ps.setInt(1, invoiceItemId);
        ps.setInt(2, cashierId);

        ps.executeUpdate();

        InvoiceHeader ivHeader = new InvoiceHeader(invoiceItemId, cashierId);
        ps.close();
        return ivHeader;

    }

    public boolean authUser(String userName, String password) throws SQLException {
        String query
                = "SELECT name,password FROM users WHERE name=? AND password=?";

        PreparedStatement ps = conn.prepareStatement(query);
        ps.setString(1, userName);
        ps.setString(2, password);

        ResultSet s = ps.executeQuery();

        while (s.next()) {
            if (s.getString("name").equals(userName) && s.getString("password").equals(password)) {

                return true;
            }

        }

        return false;

    }

    public String getRole(boolean auth, String password) throws SQLException {
        String role = "";
        if (auth) {
            String query
                    = "SELECT role FROM users WHERE password=?";

            PreparedStatement ps = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            ps.setString(1, password);

            ResultSet rs = ps.executeQuery();
        rs.beforeFirst();
            while (rs.next()) {
                role = rs.getString("role");
            }
            return role;
        } else {
            return "There is not a user with that information";
        }
    }

    public Date convertStringToDate(String dob) throws IOException {
        Date date1 = null;
        while (true) {

            try {
                date1 = new SimpleDateFormat("dd/MM/yyyy").parse(dob);

                break;
            } catch (ParseException e) {
                System.out.println("the date must be like (day/month/year)");
                String rightdate = input.readLine();
                dob = rightdate;

            }
        }
        return date1;
    }

    public String convertDateToString(Date dob) {

        String stringofdate;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        stringofdate = simpleDateFormat.format(dob);
        return stringofdate;

    }

    protected void finalize() throws SQLException {
        conn.close();
    }
}
