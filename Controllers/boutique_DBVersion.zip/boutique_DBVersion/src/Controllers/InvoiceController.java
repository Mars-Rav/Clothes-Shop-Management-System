package Controllers;

import java.util.*;

import java.util.stream.Collectors;

import Models.GarmentModel;
import Models.InvoiceModel;

import java.util.Date;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static Controllers.GarmentController.garmentTable;
import Helpers.dataBaseOperation;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class InvoiceController {

    static Scanner input = new Scanner(System.in);

    private static ArrayList<InvoiceModel> invoices = new ArrayList<>();
    private static InvoiceModel invoice;

    public static void main(String args[]) throws IOException, ParseException {
    }

    public static void addGarmentToInvoices(int invoiceId, int invoiceItemId, int cashierId, int garmentId, int quantity, double price) throws IOException, ParseException, SQLException {

        dataBaseOperation db = new dataBaseOperation();
        db.insert(invoiceId, cashierId);
        db.insert(invoiceItemId, garmentId, quantity, price);

    }

//    public static void printInvoice(){
//    	System.out.println(invoice);
//    }
//    public static void searchInvoiceById(int id){
//        readFromFile();
//        ArrayList<InvoiceModel> filtered= (ArrayList<InvoiceModel>) invoices.stream().filter(invoiceModel -> id==(invoiceModel.getInvoiceID())).collect(Collectors.toList());
//        if(filtered.isEmpty()){
//            System.out.println( "No such Invoice.");
//        }
//        else {
//            for (InvoiceModel invoiceModel : invoices){
//                System.out.printf("+---------------------------------------------------------------------------------+%n");
//                System.out.printf("+                                Invoice                                          +%n");
//                System.out.println("+*********************************************************************************+");
//                System.out.print("+");
//                System.out.printf("%15s %20s %20s %20s ", "InvoiceID: "+invoiceModel.getInvoiceID(),"EmpName: "+invoiceModel.getEmpName(), "CashierID: "+invoiceModel.getCashierID(), " Date:"+new SimpleDateFormat("MM-dd-yyyy").format( invoiceModel.getDate()));
//                System.out.println("  +");
//                System.out.println("+*********************************************************************************+");
//                System.out.print("+");
//                System.out.printf("%5s %10s %20s %20s %20s ","ID", "name","price", "quantity", "sub total price");
//                System.out.print(" +");
//                System.out.println();
//                System.out.printf("+---------------------------------------------------------------------------------+%n");
//
//                for (GarmentModel garmentModel:invoiceModel.getGarmentsList()) {
//                    System.out.print("+");
//                    System.out.format("%5s %10s %19s %18s %20s ",
//                            garmentModel.getID(), garmentModel.getName(),garmentModel.getPrice(),garmentModel.getQuantity(),garmentModel.getPrice()*garmentModel.getQuantity()
//                            );
//                    System.out.println("    +");
//
//
//                }
//                System.out.printf("+---------------------------------------------------------------------------------+%n");
//                System.out.printf("+                            "+"TotalPrice : "+invoiceModel.getTotalPrice()+"                                   +%n");
//                System.out.printf("+---------------------------------------------------------------------------------+%n");
//
//            }
//
//        }
//    }
    public static void printInvoices() throws SQLException {
        dataBaseOperation db = new dataBaseOperation();

        ResultSet rs1 = db.getAllInvoiceHeader();
        ResultSet rs2 = db.getAllInvoiceList();

//        invoices.stream().forEach(p-> System.out.println(p));
        /////////////////////////
        System.out.printf("+-----------------------------------------------------------------------+%n");
        System.out.printf("+                            Invoice                                    +%n");
        System.out.println("+***********************************************************************+");
        System.out.print("+");
        System.out.printf("%5s %10s %10s %10s %10s %15s %15s %10s", "invoiceId ", "cashierName", "created_At", "garmentName", "brand", "price", "quantity", "subTotal");
        System.out.println("       +");
        System.out.printf("+--------------------------------------------------------------------------------------------------------------------------------------------------------------------+%n");
        rs1.beforeFirst();
        rs2.beforeFirst();
        while (rs1.next() || rs2.next()) {
            System.out.print("+");
            System.out.format("%5s %10s %10s %10s %10s %15s %15s %10s",
                    rs1.getInt("invoice_id"), rs1.getString("name"), rs1.getTimestamp("created_At"), rs2.getString("name"),
                    rs2.getString("brand"), rs2.getDouble("price"), rs2.getInt("quantity"),
                    rs2.getDouble("total_price_per_cloth"));

        }
// System.out.println("           +"+rs1.getDouble("totalprice"));
//        System.out.printf("+--------------------------------------------------------------------------------------------------------------------------------------------------------------------+%n");

        System.out.printf("+---------------------------------------------------------------------------------+%n");
        System.out.printf("+                            " + "TotalPrice : " + rs1.getDouble("totalprice") + "                                   +%n");
        System.out.printf("+---------------------------------------------------------------------------------+%n");
    }

    public static void removeInvoice(int id) throws IOException, ParseException, SQLException {
        dataBaseOperation db = new dataBaseOperation();
        db.deleteInvoice(id);

    }

}
