package Controllers;

import Helpers.dataBaseOperation;
import java.util.*;

import java.util.stream.Collectors;
import Models.GarmentModel;
import Models.User;
import java.io.*;
import java.text.ParseException;
//import java.io.IOException;
//import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.text.SimpleDateFormat;

//at Controllers.CashierController.readFromFile(CashierController.java:95)
//at Controllers.CashierController.addToStaff(CashierController.java:55)
public abstract class CashierController {

    static Scanner input = new Scanner(System.in);

    private static ArrayList<User> staff = new ArrayList<>();


    public static void addToStaff() throws IOException, ParseException, SQLException {

        System.out.println("Enter ID:");
        int ID = Integer.parseInt(input.nextLine());

        System.out.println("Enter name:");
        String name = input.nextLine();

        System.out.println("Enter the gender:");
        String gender = input.nextLine();

        System.out.println("Enter phone number:");
        String phoneNumber = input.nextLine();

        System.out.println("Enter email:");
        String email = input.nextLine();

        System.out.println("Enter salary:");
        double salary = Double.parseDouble(input.nextLine());

        System.out.println("Enter address:");
        String address = input.nextLine();

        System.out.println("Enter password:");
        String password = input.nextLine();

        System.out.println("Enter the role:");
        String role = input.nextLine();

        System.out.println("Enter Date of birth:");
        String dobString = input.nextLine();
        dataBaseOperation db = new dataBaseOperation();
        staff.add(db.insert(ID, name, gender, dobString, phoneNumber, email, salary, address, password, role));

    }

    public static void printStaff() throws SQLException {
        
    dataBaseOperation db = new dataBaseOperation();
    
        stafftable(db.getAllusers());

    }

    public static void stafftable(ResultSet mystaff) throws SQLException {
        System.out.printf("+------------------------------------------------------------------------------------------------------------------------------------------------------------+%n");
        System.out.printf("+                                                                       Staff member                                                                         +%n");
        System.out.printf("+------------------------------------------------------------------------------------------------------------------------------------------------------------+%n");
        System.out.print("+");
        System.out.printf("%5s %10s %15s %12s %18s %18s %17s %15s %15s %15s ", " ID ", "NAME", "gender", "dob", "phoneNumber", "email", "salary", "address", "password", "role");
        System.out.println("      +");
        System.out.printf("+------------------------------------------------------------------------------------------------------------------------------------------------------------+%n");
        while(mystaff.next()){
            System.out.print("+");
            System.out.format("%5s %10s %15s %12s %18s %18s %17s %15s %15s %15s",
                    mystaff.getInt("user_id"), mystaff.getString("name"), mystaff.getString("gender"), mystaff.getString("dob"),
                    mystaff.getString("phoneNumber"),mystaff.getString("email"),mystaff.getDouble("salary"),mystaff.getString("address"),
                    mystaff.getString("password"),mystaff.getString("role"));
            System.out.println();
        }
        System.out.printf("+------------------------------------------------------------------------------------------------------------------------------------------------------------+%n");

    }

    public static ResultSet getStaff() throws SQLException {
        dataBaseOperation db = new dataBaseOperation();
       return(db.getAllusers()) ;
        
    }


    public static void ShowAllInvoice() throws SQLException {

        InvoiceController.printInvoices();

    }
    
    public static void addGarmentToInvoice(int invoiceId,int invoiceItemId, int cashierId,int garmentId,int quantity,double price) throws IOException, ParseException, SQLException {
    
    InvoiceController.addGarmentToInvoices(invoiceId, invoiceItemId, cashierId, garmentId, quantity, price);
    
    }
    public static void removeCashier(int id ,String name) throws IOException, ParseException, SQLException {
       dataBaseOperation db = new dataBaseOperation();
       db.delete(id, name);
    }
}
