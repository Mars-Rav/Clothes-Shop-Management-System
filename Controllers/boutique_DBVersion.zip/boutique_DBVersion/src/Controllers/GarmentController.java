package Controllers;

import Helpers.dataBaseOperation;
import java.util.*;
import java.util.ArrayList;
import java.util.stream.Collectors;

import Models.GarmentModel;
import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public abstract class GarmentController  {

    static Scanner input = new Scanner(System.in);

    private static ArrayList<GarmentModel> inventory = new ArrayList<>();
      
    
    static public void addToInventory() throws IOException, ParseException, SQLException {
    	 dataBaseOperation db = new dataBaseOperation();
    	System.out.println("Enter ID:");
        int ID = Integer.parseInt(input.nextLine());

        System.out.println("Enter name:");
        String name = input.nextLine();

        System.out.println("Enter the barcode:");
        String barcode = input.nextLine();

        System.out.println("Enter brand:");
        String brand = input.nextLine();

        System.out.println("Enter size:");
        String size = input.nextLine();

        System.out.println("Enter color:");
        String color = input.nextLine();

        System.out.println("Enter model:");
        String model = input.nextLine();

        System.out.println("Enter price:");
        double price = Double.parseDouble(input.nextLine());

        System.out.println("Enter quantity:");
        int quantity = Integer.parseInt(input.nextLine());

        System.out.println("Enter the category:");
        String category = input.nextLine();

        System.out.println("Enter Description:");
        String description = input.nextLine();

        System.out.println("Enter Discount:");
        double discount = Double.parseDouble(input.nextLine());

        inventory.add(db.insert(ID, name, barcode, brand, size, color, model, price, quantity, category, discount, description));

    }


    

    public static void printGarments() throws SQLException{
        dataBaseOperation db = new dataBaseOperation();
        
        garmentTable(db.getAllGarments());




    }
    public static void garmentTable(ResultSet myGarment ) throws SQLException{
        System.out.printf("+--------------------------------------------------------------------------------------------------------------------------------------------------------------------+%n");
        System.out.printf("+                                                                       Garments                                                                                     +%n");
//        System.out.println("+--------------------------------------------------------------------------------------------------------------------------------------------------------------------+");
        System.out.println("+********************************************************************************************************************************************************************+");
        System.out.print("+");
        System.out.printf("%5s %10s %10s %10s %10s %15s %15s %10s %10s %10s %10s %10s %20s", " ID ","NAME", "Barcode", "brand", "size", "color", "model", "price", "quantity", "category", "discount", "description","created_At");
        System.out.println("       +");
        System.out.printf("+--------------------------------------------------------------------------------------------------------------------------------------------------------------------+%n");
while(myGarment.next()){
            System.out.print("+");
            System.out.format("%5s %10s %10s %10s %10s %15s %15s %10s %10s %10s %10s %10s %20s",
                    myGarment.getInt("garment_id"), myGarment.getString("name"), myGarment.getString("barcode"), myGarment.getString("brand"),
                    myGarment.getString("size"),myGarment.getString("color"),myGarment.getString("model"),
                    myGarment.getDouble("price"),myGarment.getInt("quantity"),myGarment.getString("category"),myGarment.getDouble("discount"),
                    myGarment.getString("description"),myGarment.getTimestamp("created_At"));
            System.out.println("       +");
        }

        System.out.printf("+--------------------------------------------------------------------------------------------------------------------------------------------------------------------+%n");

    }
    
//    public static ArrayList<GarmentModel> getGarments(){
//        readFromFile();
//        ArrayList<GarmentModel> list = (ArrayList<GarmentModel>) inventory.stream().collect(Collectors.toList());
//        return inventory;
//
//    }

    public static void removeGarment(int id) throws IOException, ParseException, SQLException {
        dataBaseOperation db = new dataBaseOperation();
        db.delete(id);
    	
    }
}