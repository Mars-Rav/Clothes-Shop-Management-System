package Controllers;

import Helpers.dataBaseOperation;
import java.util.Date;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileInputStream;
import Models.GarmentModel;
import Models.InvoiceHeader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

public abstract class InvoiceHeaderController {

    public static InvoiceHeader header;
//    public InvoiceHeaderController(String cashierName, int cashierID, int invoiceID, ArrayList<GarmentModel> garmentsList) {
//
//    	 header = new InvoiceHeader(cashierName, cashierID, invoiceID, new Date(), calculateTotalPrice(garmentsList));
//    }

    public static void showHistory() throws SQLException {
        dataBaseOperation db = new dataBaseOperation();
        ResultSet rs = db.getAllInvoiceHeader();
        System.out.printf("+-----------------------------------------------------------------------+%n");
        System.out.printf("+                            Invoice History                                   +%n");
        System.out.println("+***********************************************************************+");
        System.out.print("+");
        System.out.printf("%5s %10s %10s %10s", "invoiceId ", "cashierName", "created_At", "totalPrice", "created_At");
        System.out.println("       +");
        System.out.printf("+--------------------------------------------------------------------------------------------------------------------------------------------------------------------+%n");
        rs.beforeFirst();
        while (rs.next()) {
            System.out.print("+");
            System.out.format("%5s %10s %10s %10s",
                    rs.getInt("invoice_id"), rs.getString("name"), rs.getDouble("totalprice"), rs.getTimestamp("created_At"));
            System.out.printf("+---------------------------------------------------------------------------------+%n");

        }

    }

    public static void showOneInvoice(int id) throws SQLException {
        dataBaseOperation db = new dataBaseOperation();
        ResultSet rs = db.getOneInvoiceHeader(id);
        System.out.printf("+-----------------------------------------------------------------------+%n");
        System.out.printf("+                            Invoice                                   +%n");
        System.out.println("+***********************************************************************+");
        System.out.print("+");
        System.out.printf("%5s %10s %10s %10s", "invoiceId ", "cashierName", "totalPrice", "created_At");
        System.out.println("       +");
        System.out.printf("+--------------------------------------------------------------------------------------------------------------------------------------------------------------------+%n");
        rs.beforeFirst();
        while (rs.next()) {
            System.out.print("+");
            System.out.format("%5s %10s %10s %10s",
                    rs.getInt("invoice_id"), rs.getString("name"), rs.getDouble("totalprice"), rs.getTimestamp("created_At"));
            System.out.println();
        }
        System.out.printf("+---------------------------------------------------------------------------------+%n");
    }
//    public static double calculateTotalPrice(ArrayList<GarmentModel> garmentsList) {
//    	
//		double totalPrice = 0;
//		
//		for(int i = 0; i < garmentsList.size(); i++){
//		
//			totalPrice = totalPrice + garmentsList.get(i).getPrice()*garmentsList.get(i).getQuantity();
//		}
//			
//		return totalPrice;
//	
//    }
//	public static File  file = new File("sample.txt"); //Representing the File
//	public static void writetofile() throws IOException{
//		if(!file.exists()){
//			file.createNewFile();
//		}
//		FileOutputStream fos = new FileOutputStream(file);
//		String textToBewritten = header.toString() ;
//		fos.write(textToBewritten.getBytes());
//		fos.flush();
//		fos.close();
//	}
//
//	public static void readtofile() throws IOException{
//		FileInputStream fis = new FileInputStream(file);
//		int i = fis.read();
//		while(!(i==-1)) {
//			char c = (char)i;
//			System.out.print(c);
//			i = fis.read();
//		}
//		fis.close();
//	}
}
