package View;

import java.io.IOException;
import java.text.ParseException;
import java.util.Scanner;
import Controllers.CashierController;
import Controllers.GarmentController;
import Controllers.InvoiceController;
import Controllers.InvoiceHeaderController;
import Models.User;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import static Controllers.InvoiceController.removeInvoice;
import java.sql.SQLException;

public class CashierView {
	
	private static Scanner input = new Scanner(System.in);
       
        
	public static void optionSelection() throws IOException, ParseException ,UnknownHostException, ClassNotFoundException, InterruptedException, SQLException {
		
                   
                switch(displayCashierOptions()) {
                    
		case 1:
                    System.out.println("Enter invoice id:");
                    int invoiceId=input.nextInt();
                    System.out.println("Enter invoice item id:");
                    int invoiceItemId=input.nextInt();
                    System.out.println("Enter cashier id:");
                    int cashierId=input.nextInt();
                    System.out.println("Enter garment id:");
                    int garmentId=input.nextInt();
                    System.out.println("Enter quantity:");
                    int quantity=input.nextInt();
                    System.out.println("Enter garment id:");
                    double price=input.nextDouble();
			InvoiceController.addGarmentToInvoices(invoiceId, invoiceItemId, cashierId, garmentId, quantity, price);
			InvoiceController.printInvoices();
			break;
		case 2:

                    
                    GarmentController.printGarments();
                   
			break;
		case 3:

			InvoiceHeaderController.showHistory();
			break;
		case 4:
			System.out.println("Enter the ID of the Invoice you want to search for:");
			int id = Integer.parseInt(input.nextLine());
			InvoiceHeaderController.showOneInvoice(id);
			break;
		case 5:

			System.exit(0);
			break;
			default:
				System.out.println("Please enter valid input.");
		}
                
	}
	
	private static int displayCashierOptions() throws IOException, ClassNotFoundException, UnknownHostException {
		System.out.println("Enter the number of the function you want:");
		System.out.println("1. Create a new invoice.");
		System.out.println("2. Display garments");
		System.out.println("3. Show history.");
		System.out.println("4. search Invoice ById");
		System.out.println("5. Exit.");
		return Integer.parseInt(input.nextLine());
	}

}
