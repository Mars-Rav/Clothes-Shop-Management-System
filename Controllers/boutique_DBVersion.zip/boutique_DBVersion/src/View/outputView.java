/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Controllers.CashierController;
import Controllers.Manager;
import Helpers.dataBaseOperation;
import Models.User;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class outputView {
      static Scanner input = new Scanner(System.in);
	static User cashier;
    public void output(PrintWriter p , BufferedReader b) throws IOException, ParseException, UnknownHostException, ClassNotFoundException, InterruptedException, SQLException{
      
    boolean state = true;
		
		switch(logIn()) {
                    
                    case 0:
			System.out.println("Please make sure you entered the right info.");
			break;
                        
		case 1:
			while(true) {
				System.out.println();
				System.out.println("------------------------------------------------");
				System.out.println();
				CashierView.optionSelection();
			}
		case 2:
			
			System.out.println("------------------- Welcome -------------------");
			while(true) {
				System.out.println();
				System.out.println("------------------------------------------------");
				System.out.println();
				ManagerView.optionSelection();
			}
		
		default:
			System.out.println("Invalid input.");
		}
		
		
	}
	
	public static int logIn()throws IOException, ParseException, SQLException {
            dataBaseOperation db = new dataBaseOperation();
           
		System.out.println("Enter your username:");
		String username = input.nextLine();
		System.out.println("Enter your password:");
		String password = input.nextLine();
		 boolean checkAuth=db.authUser(username, password);
                 String role=db.getRole(checkAuth, password);
		if(checkAuth==true && role.equals("cashier")){
                return 1;
                }
			
                else if(checkAuth==true && role.equals("admin")){
                return 2;
                }
                else{
                return 0;
                }
	}
	
    
    }
