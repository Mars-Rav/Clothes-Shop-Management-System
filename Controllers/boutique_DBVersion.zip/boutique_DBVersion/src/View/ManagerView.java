package View;

import java.io.EOFException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Scanner;

import Controllers.CashierController;
import Controllers.GarmentController;
import Controllers.InvoiceController;
import Controllers.Manager;

import static Controllers.InvoiceController.removeInvoice;
import java.sql.SQLException;

public class ManagerView {

	private static Scanner input = new Scanner(System.in);

	public static void optionSelection() throws IOException, ParseException, SQLException {
		switch(displayManagerOptions()) {
		case 1:
			
				GarmentController.addToInventory();
			break;
		case 2:
			GarmentController.printGarments();
			break;
		case 3:
			CashierController.addToStaff();
			break;
		case 4:
			CashierController.printStaff();
			break;
                        
		case 5:
		InvoiceController.printInvoices();
		
                break;
	
			case 6:
				System.out.println("Enter the ID of the invoice you want to  remove :");
				int idremove = Integer.parseInt(input.nextLine());
				InvoiceController.removeInvoice(idremove);
				break;
			case 7:
				System.out.println("Enter the ID of the garment you want to remove:");
						int removeGarmentid = Integer.parseInt(input.nextLine());
						GarmentController.removeGarment(removeGarmentid);
				break;
			case 8:
				System.out.println("Enter the name of the cashier you want to remove:");
                                String removeCashiername = input.nextLine();
                                System.out.println("Enter the ID of the cashier you want to remove:");
				int removeCashierId = Integer.parseInt(input.nextLine());
                                CashierController.removeCashier(removeCashierId, removeCashiername);
				break;
		case 9:
			System.exit(0);
			break;
		}
	}

	private static int displayManagerOptions() {
		System.out.println("Enter the number of the function you want:");
		System.out.println("1. Add a new garment.");
		System.out.println("2. Display garments.");
		System.out.println("3. Add a new cashier.");
		System.out.println("4. Display cashiers.");
		System.out.println("5. show invoice.");
		System.out.println("6. remove Invoice.");
		System.out.println("7. remove garment.");
		System.out.println("8. remove cashier.");
		System.out.println("9. Exit.");
		return Integer.parseInt(input.nextLine());
	}

}
